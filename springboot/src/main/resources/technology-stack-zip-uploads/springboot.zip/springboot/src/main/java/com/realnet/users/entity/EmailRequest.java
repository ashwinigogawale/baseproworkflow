package com.realnet.users.entity;

import lombok.Data;

@Data
public class EmailRequest {
	private String email;
}
