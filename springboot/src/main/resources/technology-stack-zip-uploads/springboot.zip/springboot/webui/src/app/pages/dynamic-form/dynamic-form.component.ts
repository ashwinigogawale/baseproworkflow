import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss'],
  encapsulation: ViewEncapsulation.Emulated
})
export class DynamicFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
