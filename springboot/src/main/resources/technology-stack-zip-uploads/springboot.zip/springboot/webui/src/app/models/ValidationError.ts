export class ValidationError {
    field: any;
    message: any;
}