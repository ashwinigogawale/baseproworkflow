import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-ext',
  templateUrl: './add-ext.component.html',
  styleUrls: ['./add-ext.component.scss']
})
export class AddExtComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
