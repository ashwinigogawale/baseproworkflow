
export class department {
    id: number;
    dname: String;
    dhead: String;
    dcontact: number;
    empCount: number;



}