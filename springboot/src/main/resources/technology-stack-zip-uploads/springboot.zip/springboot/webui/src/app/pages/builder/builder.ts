export class builder {
    id: number;
    form_id: number;
    form_version: number;
    header_id: number;
    createdAt: Date;
    updatedAt: Date;
    createdBy: number;
    updatedBy: number;
    comp1: String;
    comp2: String;
    comp3: String;
    comp4: String;
    comp5: String;
    comp6: String;
    comp7: String;
    comp8: String;
    comp9: String;
    comp10: String;
    comp11: String;
    comp12: String;
    comp13: String;
    comp14: String;
    comp15: String;
    comp16: String;
    comp17: String;
    comp18: String;
    comp19: String;
    comp20: String;
    comp21: String;
    comp22: String;
    comp23: String;
    comp24: String;
    comp25: String;
    comp_l26: String;
    comp_l27: String;
    comp_l28: String;
    comp_l29: String;
    comp_l30: String;


}