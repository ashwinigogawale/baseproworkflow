export class SalesPerson {
    id: number;
    name: String;
}