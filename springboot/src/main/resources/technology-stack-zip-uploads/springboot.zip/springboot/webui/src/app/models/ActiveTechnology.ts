export interface ActiveTechnology {
    id: number;
	name: string;
}