import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-function-register',
	templateUrl: './function-register.component.html',
    styleUrls: [ './function-register.scss'],
})
export class FunctionRegisterComponent implements OnInit {
    constructor(){}
    ngOnInit() {}
}
