import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-forms-setup',
  templateUrl: './forms-setup.component.html',
  styleUrls: ['./forms-setup.component.scss'],
  encapsulation: ViewEncapsulation.Emulated
})
export class FormsSetupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
