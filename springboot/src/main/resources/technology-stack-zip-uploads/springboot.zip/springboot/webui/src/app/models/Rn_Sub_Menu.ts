import { Audit } from "./Audit";

export class Rn_Sub_Menu extends Audit {
    public id: number;
	public sub_menu_name: string;
	public sub_menu_icon: string;
	public sub_menu_action_link : string;
	//public menu_icon: string;
}